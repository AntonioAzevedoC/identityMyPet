<!-- Menu de navegação -->
<div class="menu">
    <button onclick="window.location.href = 'index.php'">
        <div class="menuItem" id="btnPet">
            <i class="fa fa-paw" id="iPet" aria-hidden="true"></i>
        </div>
    </button>
    <button onclick="window.location.href = 'userArea.php'">
        <div class="menuItem" id="btnUser">
            <i class="fa fa-user" id="iUser" aria-hidden="true"></i>
        </div>
    </button>
</div>